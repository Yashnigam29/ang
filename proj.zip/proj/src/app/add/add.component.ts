import { Component, OnInit } from '@angular/core';
import { ProductserveService} from '../productserve.service'
import { Product } from '../product';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'],
  providers:[ProductserveService]
})
export class AddComponent implements OnInit {
  products: Product[]=[];
  pro:Product=new Product();
  constructor(private ProductserveService:ProductserveService) { }

  ngOnInit() {
  }
add():void{
  var a=(document.getElementById("pid")as HTMLInputElement).value;
  var b=(document.getElementById("name")as HTMLInputElement).value;
  var c=(document.getElementById("desc")as HTMLInputElement).value;
  var d=(document.getElementById("price")as HTMLInputElement).value;
  if(a==""||b==""||c==""||d==""){
     alert("all field is required");
  }
  else{
        this.ProductserveService.addpro(this.pro);
 this.products=this.ProductserveService.getProduct();
 console.log(JSON.stringify(this.pro))
    console.log(JSON.stringify(this.products))
     this.pro=new Product();
  }
}
id():boolean{
  console.log("dsf");
  var a=(document.getElementById("pid")as HTMLInputElement).value;
  var b="/^[0-9]+$/";
  if(a.match(b))
  {
    return true;
  }
  else{
    alert("enter only numbers");
    return false;
  }
}

 
}

