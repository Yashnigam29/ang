import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductserveService } from '../productserve.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers:[ProductserveService]
})
export class ProductComponent implements OnInit {
  products:Product[];
  constructor(private ProductserveService:ProductserveService) { }

  ngOnInit() {
    this.ProductserveService.getProduct().subscribe((prodData:Product[])=>this.products=prodData);
  }
  remove(proid:Number):void{
    this.products=this.products.filter(x=> x.id!=proid);
    console.log(JSON.stringify(this.products));
  }

}
