import { Injectable } from '@angular/core';
// import { Product } from './product';
// import { Http,Response} from '@angular/http';
// import { Observable } from 'rxjs/Observable';
// import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http'
import { Product } from './product';
// import { Product1 } from '../assets/product';
@Injectable()
export class ProductserveService {
  products:Product[]=[];
  constructor(private http:HttpClient) { }
  
  addpro(e:Product):ProductserveService{
    console.log("service"+JSON.stringify(e))
    this.products.push(e);
    return this;
  }

  getProduct():any{
    return this.http.get('assets/product.json');
    // .map((resp:Response)=>resp.json());

  }

}
