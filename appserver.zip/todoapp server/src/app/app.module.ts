import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from  '@angular/forms';
import{HttpModule} from '@angular/http';
import { AppComponent } from './app.component';
import { TaskComponent } from './task/task.component';
import { FooterComponent } from './footer/footer.component';
import { DisplayComponent } from './display/display.component';
import { InsertComponent } from './insert/insert.component';

@NgModule({
  declarations: [
    AppComponent,
    TaskComponent,
    FooterComponent,
    DisplayComponent,
    InsertComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
