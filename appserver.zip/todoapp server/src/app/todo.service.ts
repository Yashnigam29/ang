import { Injectable } from '@angular/core';
import { Task } from './task';
import{Http,Response} from '@angular/http'
import{Observable} from 'rxjs/Observable';
import "rxjs/add/operator/catch";
import "rxjs/add/operator/map";


@Injectable()
export class TodoService {

  counter:number=0;
  task:Task[]=[];
  constructor(private http:Http) { }

addTask(t:Task):Observable< Task[]>{
  //  if(!t.id){
  //    t.id=++this.counter;
  //  }
  //  console.log(JSON.stringify(t));
  // this.task.push(t);
  return this.http.post("http://localhost:3000/Tasks",t).map((response:Response)=><Task[]>response.json());
}

getAllTask(): Observable< Task[]>{
   return this.http.get("http://localhost:3000/Tasks").map((response:Response)=><Task[]>response.json());

}
removeTask(id:number):Observable<Task[]>{
  return this.http.delete("http://localhost:3000/Tasks/"+id).map((response:Response)=><Task[]>response.json()).catch(this.handleError);
//  this.task=this.task.filter(x=> x.id!=taskId)
//   return this;
}
handleError(error:Response){
  console.error(error);
return Observable.throw(error);
}
}
