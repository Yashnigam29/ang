export class Task {
    id:Number;
    taskName:string;
    complete:boolean=false;
    
}
