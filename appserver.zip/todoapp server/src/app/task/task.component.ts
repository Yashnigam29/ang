import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
import { TodoService } from '../todo.service';
import { Observable } from '../../../node_modules/rxjs/Observable';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css'],
  providers:[TodoService]
})
export class TaskComponent implements OnInit {

  
   //taskName:string='';
   counter:number=0;
   tasks:Task[]=[]; 
   task:Task=new Task();
  constructor(private todoService:TodoService) { }

  ngOnInit() {
    this.todoService.getAllTask().subscribe((taskData)=> this.tasks=taskData);
  }

  addTask(task):void{
  
    // console.log("task added"+JSON.stringify(this.task));
     this.todoService.addTask(task).subscribe((taskData)=>{this.todoService.getAllTask().subscribe((taskData)=> this.tasks=taskData);});
    
    // this.todoService.getAllTask().subscribe((taskData)=> this.tasks=taskData);
    console.log(JSON.stringify(this.tasks));

  //    this.task=new Task();
  //  this.task.taskName=this.taskName;
  //  if(!this.task.taskId){
  //      this.task.taskId=++this.counter;
  //  }

//    console.log("task added"+JSON.stringify(this.task));
//  }
  }
 
//   removeTask(id:number):void{
//     console.log("button clicked"+id);
//     this.todoService.removeTask(id).subscribe((todoData)=> this.todoService.getAllTask().subscribe((data)=>this.tasks=data),
//        (error)=>{
//          console.error(error);
//        })
//     this.todoService.getAllTask()
//   console.log(JSON.stringify(this.tasks))
//   }
//   updateTask():void{
//     console.log("update button clicked");
//   }
}
