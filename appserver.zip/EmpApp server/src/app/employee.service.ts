import { Injectable } from '@angular/core';
import { Emp } from './emp';

import{Http,Response} from '@angular/http';
import{Observable} from 'rxjs/Observable';
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
@Injectable()
export class EmployeeService {

  counter:number=0;
  emp:Emp[]=[];
  constructor(private http:Http) { }
  
  addEmp(emp:Emp):Observable<Emp[]>{
   return this.http.post("http://localhost:3000/empl",emp).map((response:Response)=><Emp[]>response.json());
  //   if(!e.id){
  //     e.id=++this.counter;
  //   }+

  //     console.log(JSON.stringify(e));
  // this.emp.push(e);
    //  return this;
  }
  getAllEmp():Observable< Emp[]>{
    return this.http.get("http://localhost:3000/empl").map((response:Response)=><Emp[]>response.json());
  }
  removeEmployee(id:number):Observable<Emp[]>{
    return this.http.delete("http://localhost:3000/empl/"+id).map((response:Response)=><Emp[]>response.json()).catch(this.handleError);
  //  this.task=this.task.filter(x=> x.id!=taskId)
  //   return this;
  }
  handleError(error:Response){
    console.error(error);
  return Observable.throw(error);
  }
  updateEmployee(e:Emp):Observable<Emp[]>{
return this.http.put(("http://localhost:3000/empl/"+e.id),e).map((response:Response)=><Emp[]>response.json()).catch(this.handleError);
  //  this.removeEmployee(e.id);
  //   this.addEmp(e);
  //   return this;
  }
}
