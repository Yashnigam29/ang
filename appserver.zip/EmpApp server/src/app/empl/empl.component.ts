import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-empl',
  templateUrl: './empl.component.html',
  styleUrls: ['./empl.component.css'],
  providers:[EmployeeService]
})
export class EmplComponent implements OnInit {

  emps:Emp[]=[];
  emp:Emp=new Emp();
  constructor(private employeeservice:EmployeeService) { }

  ngOnInit() {
    this.employeeservice.getAllEmp().subscribe((taskData)=> this.emps=taskData);
  }
    addEmp():void{
     if(!this.emp.id)
      {
    //   this.employeeservice.addEmp(this.emp);
    //   // this.emps=this.employeeservice.getAllEmp();
    //   console.log(JSON.stringify(this.emp));
    //   console.log(JSON.stringify(this.emps));
    //  this.emp=new Emp();
    // }
    // else{
    //   this.employeeservice.updateEmployee(this.emp);
    // }
 
    this.employeeservice.addEmp(this.emp).subscribe((EmpData)=> this.employeeservice.getAllEmp().subscribe((data)=>this.emps=data),
      (error)=>{
        console.error(error);
      })
    }
    else{
      this.employeeservice.updateEmployee(this.emp).subscribe((EmpData)=> this.employeeservice.getAllEmp().subscribe((data)=>this.emps=data),
      (error)=>{
        console.error(error);
      })
    }
    // this.employeeservice.getAllEmp().subscribe((taskData)=> this.emps=taskData);

   }
   removeEmployee(id:number):void{
      console.log("remove button"+id);
      this.employeeservice.removeEmployee(id).subscribe((EmpData)=> this.employeeservice.getAllEmp().subscribe((data)=>this.emps=data),
      (error)=>{
        console.error(error);
      })
      this.employeeservice.removeEmployee(id);
      // this.employeeservice.getAllEmp().subscribe((taskData)=> this.emps=taskData);
      console.log(JSON.stringify(this.emps));
   }
   updateEmployee(e:Emp):void{
     console.log("update button entered");
    
     Object.assign(this.emp,e);
   }
}
