export class Emp {
    id:number;
    empName:string;
    empSalary:number;
    Department:String;
}
